# games_oop_javafx
This project demonstrates how to use Java Fx in OOP Style. 
All examples are popular games. (Chess, TicTacToe, SeeBattle and etc)

##TicTacToe

![ScreenShot](images/TicTacToe.png)

##Chess

![ScreenShot](images/Chess.png)
