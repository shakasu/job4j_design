# job4j_design
Статистика проекта:
[![codecov](https://codecov.io/gh/shakasu/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/shakasu/job4j_design)
[![Build Status](https://travis-ci.org/shakasu/job4j_design.svg?branch=master)](https://travis-ci.org/shakasu/job4j_design)
